# OpenClaw and MCP setup

TRAECNclaw supports two integrations:

- The focused stdio MCP server is the preferred Agent interface.
- The OpenClaw plugin retains broader operator commands for existing OpenClaw deployments.

Do not infer the MCP tool list from OpenClaw plugin commands. They serve
different audiences.

## Requirements

- Node.js 22 or later
- TraeCN with CDP remote debugging enabled
- TRAECNclaw gateway on `127.0.0.1:8788`

Verify the environment:

```sh
npm install
npm run doctor
npm run start:gateway
```

## MCP client

Validate the matching server and render the Skill launcher entry from a source
checkout:

```sh
npm run --silent setup:mcp
```

The `--silent` flag keeps stdout as pure JSON. To create a new mode-0600 file
atomically, without replacing an existing file, run:

```sh
npm run setup:mcp -- --output ./traecnclaw-mcp.json
```

Merge the resulting `mcpServers.traecn` entry into the host configuration and
restart or reconnect the host. A standalone Skill installation can run
`node scripts/setup-mcp.js`; setup fails before writing when it cannot locate a
matching repository server, installed `traecnclaw` package, or
`traecnclaw-mcp` executable.

The generated entry uses the skill launcher:

```json
{
  "mcpServers": {
    "traecn": {
      "command": "node",
      "args": ["/absolute/path/to/TRAECNclaw/skills/traecnclaw-mcp/scripts/start-mcp.js"],
      "env": {
        "TRAECN_GATEWAY_HOST": "127.0.0.1",
        "TRAECN_GATEWAY_PORT": "8788",
        "TRAECN_GATEWAY_TOKEN": ""
      }
    }
  }
}
```

The MCP surface contains focused work, context, conversation, question, and
approval and UI-backed settings tools. See
[MCP Server Guide](MCP-SERVER-GUIDE.md) for the 20 names.

Send example after any required context-selection calls:

```json
{
  "message": "Inspect the current repository for correctness and safety issues."
}
```

The gateway returns `taskId`, maintains any queue, and pushes completion through
MCP logging notifications for legacy initialization-based clients. Modern MCP
`2026-07-28` hosts can negotiate `io.modelcontextprotocol/tasks`: an opted-in
send returns a durable Task, and `subscriptions/listen` can deliver the final
`notifications/tasks` result without polling. Hosts without extension support
use `traecn_get_task` for an intentional later read. The caller does not need
gateway wait, recovery, preflight, proof, cleanup, or review-gate tools, and
should not busy-poll.

For legacy notifications, a new `TRAECN_MCP_CLIENT_ID` baselines events retained
before that client first connected. Reusing the same ID after a disconnect
resumes its durably unacknowledged events. Assign different IDs to concurrent
host installations.

## OpenClaw plugin

The plugin under `integrations/openclaw-traecn-plugin` exposes existing
OpenClaw-specific commands for deployment compatibility and operator workflows.
Its broader command catalog does not change the focused MCP contract.

Configure the plugin with the same gateway host, port, and optional token. Keep
the gateway bound to loopback unless remote access is secured.

## Approval behavior

The gateway never auto-approves shell commands, including commands classified
as read-only. Every command is returned for `traecn_decide_approval`, which
revalidates the exact visible command and requires a risk acknowledgement and
audit reason. The gateway can still answer documented non-command review-scope
questions and keeps generated file changes by default, reverting only when the
collected state contains a clear fatal automation failure.

High-impact tools remain focused but policy-backed: direct stop is bound to the
active Solo conversation and requires an untracked-work acknowledgement;
permanent deletion requires an inactive exact-title match; unsafe approval
requires exact-command revalidation. Each records a concise reason in the local
append-only audit log instead of adding a separate confirmation tool.

## Troubleshooting

| Symptom | Check |
| --- | --- |
| MCP initializes with no tools | Absolute launcher path and Node.js version |
| `setup-mcp` says the server is not installed | Install the matching server archive/package or run setup from its source checkout |
| Gateway request returns `ECONNREFUSED` | `npm run start:gateway` |
| HTTP 401 | Client and gateway token values |
| CDP unavailable | TraeCN remote-debugging process and configured port |
| Workspace cannot switch | Requested absolute path and TraeCN binary discovery |
| Legacy completion notification missing | MCP logging support, a stable `TRAECN_MCP_CLIENT_ID`, and whether this is its first connection whose prior history was intentionally baselined |
| Modern client shows no pushed completion | Confirm the host declares `io.modelcontextprotocol/tasks` and opens `subscriptions/listen`; otherwise read the known task intentionally with `traecn_get_task` |

Run `npm run test:mcp-stdio-smoke` for protocol discovery and
`npm run check:skill-contracts` for schema/example consistency.
