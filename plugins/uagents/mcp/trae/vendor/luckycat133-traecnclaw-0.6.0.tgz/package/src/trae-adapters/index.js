'use strict';

module.exports = {
  ...require('./detect'),
  ...require('./registry')
};
