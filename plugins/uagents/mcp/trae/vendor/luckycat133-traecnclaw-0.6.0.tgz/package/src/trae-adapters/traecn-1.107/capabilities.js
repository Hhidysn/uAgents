'use strict';

module.exports = Object.freeze({
  conversationIdentity: true,
  reviewGate: true,
  settingsUI: true,
  structuredTaskState: false,
  fixtureReplay: true
});
